var searchData=
[
  ['gdatabuf_403',['gDATABUF',['../network_8h.html#ac8884369d63ea1438a3c3c6dd582c633',1,'network.h']]]
];
