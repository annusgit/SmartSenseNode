var searchData=
[
  ['machine_5fidle_448',['MACHINE_IDLE',['../current__sensor_8h.html#aaf7da482440a7021c7cccd7706742ee1a1ea1956941780e8d0f009df515a79ada',1,'current_sensor.h']]],
  ['machine_5foff_449',['MACHINE_OFF',['../current__sensor_8h.html#aaf7da482440a7021c7cccd7706742ee1a830bbd60935892334f4e6b5a2a0468ae',1,'current_sensor.h']]],
  ['machine_5fon_450',['MACHINE_ON',['../current__sensor_8h.html#aaf7da482440a7021c7cccd7706742ee1a47e8e374cafda6af1c95de6b59eca7df',1,'current_sensor.h']]],
  ['machine_5freset_5fsentinel_5fstate_451',['MACHINE_RESET_SENTINEL_STATE',['../current__sensor_8h.html#aaf7da482440a7021c7cccd7706742ee1a2ac50fcf14931c40f34d4330346ae48b',1,'current_sensor.h']]]
];
