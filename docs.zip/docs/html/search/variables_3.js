var searchData=
[
  ['half_5fsecond_5fcounter_404',['half_second_counter',['../main_8c.html#ad45fec976ad953004fd5c2db30b01c25',1,'main.c']]],
  ['hours_405',['hours',['../structpseudo__clock.html#a700315a947a973ca3c6d29428749ddef',1,'pseudo_clock']]]
];
