var searchData=
[
  ['i_406',['i',['../main_8c.html#af27e3188294c2df66d975b74a09c001d',1,'main.c']]],
  ['interrupts_5fper_5fsecond_407',['interrupts_per_second',['../main_8c.html#a56d35d75f15c139534abac2f3b6fa427',1,'main.c']]]
];
