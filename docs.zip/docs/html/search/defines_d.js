var searchData=
[
  ['wiz5500_5fr_5fcommon_5frcr_532',['WIZ5500_R_COMMON_RCR',['../network_8h.html#ac0c788aa8a4a48207a4a4e4305162c36',1,'network.h']]],
  ['wiz5500_5fr_5fcommon_5frtr_533',['WIZ5500_R_COMMON_RTR',['../network_8h.html#a8624d172c4f67fed3b3fe5a62a46ca1a',1,'network.h']]],
  ['wiz5500_5fw_5fcommon_5frcr_534',['WIZ5500_W_COMMON_RCR',['../network_8h.html#aea47c1c7deba204d3a0888fd6740402f',1,'network.h']]],
  ['wiz5500_5fw_5fcommon_5frtr_535',['WIZ5500_W_COMMON_RTR',['../network_8h.html#a7de1b6acc169bc96ec2ae49513914f16',1,'network.h']]]
];
