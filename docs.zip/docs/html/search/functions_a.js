var searchData=
[
  ['open_5fadc_350',['open_ADC',['../current__sensor_8c.html#af4efc6ea0c8849c1c2694f8cfc2e8e8e',1,'open_ADC():&#160;current_sensor.c'],['../current__sensor_8h.html#af4efc6ea0c8849c1c2694f8cfc2e8e8e',1,'open_ADC():&#160;current_sensor.c']]],
  ['open_5fi2c1_351',['open_I2C1',['../eeprom_8c.html#af9914f40ecc88b132eef730883a8f51f',1,'open_I2C1():&#160;eeprom.c'],['../eeprom_8h.html#af9914f40ecc88b132eef730883a8f51f',1,'open_I2C1():&#160;eeprom.c']]],
  ['open_5fi2c2_352',['open_I2C2',['../temperature__sensor_8c.html#a0c7dc69e2ed0d2619972eb9848340612',1,'open_I2C2():&#160;temperature_sensor.c'],['../temperature__sensor_8h.html#a0c7dc69e2ed0d2619972eb9848340612',1,'open_I2C2():&#160;temperature_sensor.c']]],
  ['open_5fspi2_353',['open_SPI2',['../network_8c.html#a47c018d784ebc480ba8c0650651af1da',1,'open_SPI2():&#160;network.c'],['../network_8h.html#a47c018d784ebc480ba8c0650651af1da',1,'open_SPI2():&#160;network.c']]],
  ['open_5fuart2_354',['open_UART2',['../uart_8c.html#ac1f14baa3de857ce0d2f996fba315cdb',1,'open_UART2(unsigned int baudrate):&#160;uart.c'],['../uart_8h.html#ac1f14baa3de857ce0d2f996fba315cdb',1,'open_UART2(unsigned int baudrate):&#160;uart.c']]]
];
