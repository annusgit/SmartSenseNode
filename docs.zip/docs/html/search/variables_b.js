var searchData=
[
  ['year_440',['year',['../structpseudo__clock.html#aa63a0f03ef96f7a7126df48d07afc734',1,'pseudo_clock']]]
];
