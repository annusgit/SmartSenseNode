var searchData=
[
  ['machine_5fload_5fcurrents_408',['Machine_load_currents',['../main_8c.html#abe9c0cc707863ac4653ed10a04306c30',1,'main.c']]],
  ['machine_5fload_5fpercentages_409',['Machine_load_percentages',['../main_8c.html#a29207fa3772e4346d6fc95f5cd43ffb1',1,'main.c']]],
  ['machine_5fstatus_410',['Machine_status',['../main_8c.html#a7b37f58d5c84e0d6bfbc082e0f4acf57',1,'main.c']]],
  ['machine_5fstatus_5fduration_411',['Machine_status_duration',['../main_8c.html#af06d36f7bd07ba0529591d9d30f25dff',1,'main.c']]],
  ['machine_5fstatus_5ftimestamp_412',['Machine_status_timestamp',['../main_8c.html#a15b39a8db0ae226b5f8fc4f53fac16c2',1,'main.c']]],
  ['machines_5fstate_5ftime_5fmarkers_413',['MACHINES_STATE_TIME_MARKERS',['../current__sensor_8h.html#ac56e99b35c34d2843f9cef0ea1149edc',1,'current_sensor.h']]],
  ['minutes_414',['minutes',['../structpseudo__clock.html#abed3bb8c7a3170a59c88f593635db2ab',1,'pseudo_clock']]],
  ['month_415',['month',['../structpseudo__clock.html#a9dad7b8bf33b6c588230bc3e41b84dd9',1,'pseudo_clock']]],
  ['msticks_416',['msTicks',['../network_8h.html#a0a6e5e17fcb15f3922e278025acabfa2',1,'network.h']]]
];
