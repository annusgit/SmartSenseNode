var searchData=
[
  ['red_5fled_513',['RED_LED',['../global_8h.html#a073dbcb7f5bc4f4b45dc048b55eaff3d',1,'global.h']]],
  ['reset_5fmachine_5ftime_5fmessage_5fid_514',['RESET_MACHINE_TIME_MESSAGE_ID',['../messages_8h.html#ae473cfca946dcf2b8b46c9c9be041347',1,'messages.h']]],
  ['reset_5fmachine_5ftime_5fmessage_5fsize_515',['RESET_MACHINE_TIME_MESSAGE_Size',['../messages_8h.html#a2c249f901c89907c67abe51239271207',1,'messages.h']]]
];
