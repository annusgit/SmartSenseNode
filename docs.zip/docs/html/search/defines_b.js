var searchData=
[
  ['time_5fof_5fday_5fsize_530',['TIME_Of_DAY_SIZE',['../global_8h.html#aef41ead83ec2a5e8d8fd17f1c18ea195',1,'global.h']]]
];
