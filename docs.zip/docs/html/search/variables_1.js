var searchData=
[
  ['day_401',['day',['../structpseudo__clock.html#a7209e6a943cd8a59a614d31a904cade7',1,'pseudo_clock']]],
  ['days_5fin_5fa_5fmonth_402',['Days_in_a_Month',['../pseudo__rtcc_8c.html#a018c770c808352224b7f1cd146587f84',1,'pseudo_rtcc.c']]]
];
